"""Synthetic long-memory tasks for testing UABLA routing."""

from __future__ import annotations

from dataclasses import dataclass

try:
    import torch
    from torch.utils.data import Dataset
except ModuleNotFoundError:  # pragma: no cover - lets non-torch config tests import the package.
    torch = None
    Dataset = object


@dataclass(frozen=True)
class KeyValueRecallConfig:
    """Configuration for fixed-length key-value recall samples."""

    seq_len: int = 128
    num_pairs: int = 8
    num_keys: int = 64
    num_values: int = 64
    filler_vocab: int = 32
    dataset_size: int = 2048
    seed: int = 0

    def __post_init__(self) -> None:
        if self.seq_len < self.num_pairs * 3 + 3:
            raise ValueError("seq_len must fit all key/value pairs plus final query")
        if self.num_pairs <= 0:
            raise ValueError("num_pairs must be positive")
        if self.num_pairs > self.num_keys:
            raise ValueError("num_pairs cannot exceed num_keys")
        if self.num_keys <= 0 or self.num_values <= 0 or self.filler_vocab <= 0:
            raise ValueError("vocab sizes must be positive")
        if self.dataset_size <= 0:
            raise ValueError("dataset_size must be positive")

    @property
    def filler_start(self) -> int:
        return 1

    @property
    def key_start(self) -> int:
        return self.filler_start + self.filler_vocab

    @property
    def value_start(self) -> int:
        return self.key_start + self.num_keys

    @property
    def sep_token(self) -> int:
        return self.value_start + self.num_values

    @property
    def query_token(self) -> int:
        return self.sep_token + 1

    @property
    def vocab_size(self) -> int:
        return self.query_token + 1

    @property
    def model_seq_len(self) -> int:
        return self.seq_len - 1


class KeyValueRecallDataset(Dataset):
    """Generate sequences where the final query asks for an earlier value.

    Full sequence format:

    ```text
    key value sep key value sep ... filler ... QUERY key value
    ```

    Models receive `tokens[:-1]` and must predict `tokens[1:]`. Answer accuracy
    is measured at the final input position, where the target is the value.
    """

    def __init__(self, config: KeyValueRecallConfig) -> None:
        if torch is None:
            raise ModuleNotFoundError("KeyValueRecallDataset requires torch")
        self.config = config

    def __len__(self) -> int:
        return self.config.dataset_size

    def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
        config = self.config
        generator = torch.Generator()
        generator.manual_seed(config.seed + index)

        tokens = torch.randint(
            low=config.filler_start,
            high=config.filler_start + config.filler_vocab,
            size=(config.seq_len,),
            generator=generator,
            dtype=torch.long,
        )

        keys = torch.randperm(config.num_keys, generator=generator)[: config.num_pairs]
        values = torch.randint(
            low=0,
            high=config.num_values,
            size=(config.num_pairs,),
            generator=generator,
            dtype=torch.long,
        )
        pair_tokens = torch.empty(config.num_pairs * 3, dtype=torch.long)
        pair_tokens[0::3] = config.key_start + keys
        pair_tokens[1::3] = config.value_start + values
        pair_tokens[2::3] = config.sep_token
        tokens[: pair_tokens.numel()] = pair_tokens

        query_pair_idx = int(torch.randint(config.num_pairs, (1,), generator=generator).item())
        query_key = config.key_start + keys[query_pair_idx]
        answer_token = config.value_start + values[query_pair_idx]
        tokens[-3] = config.query_token
        tokens[-2] = query_key
        tokens[-1] = answer_token

        return {
            "input_ids": tokens[:-1].clone(),
            "labels": tokens[1:].clone(),
            "answer_index": torch.tensor(config.seq_len - 2, dtype=torch.long),
            "answer_token": answer_token.clone(),
            "query_key": query_key.clone(),
            "value_start": torch.tensor(config.value_start, dtype=torch.long),
            "num_values": torch.tensor(config.num_values, dtype=torch.long),
        }


def answer_cross_entropy(logits: torch.Tensor, batch: dict[str, torch.Tensor]) -> torch.Tensor:
    """Cross-entropy at the synthetic task's answer position."""

    if torch is None:
        raise ModuleNotFoundError("answer_cross_entropy requires torch")
    batch_indices = torch.arange(logits.shape[0], device=logits.device)
    answer_logits = logits[batch_indices, batch["answer_index"].to(logits.device)]
    return torch.nn.functional.cross_entropy(answer_logits, batch["answer_token"].to(logits.device))


def answer_accuracy(logits: torch.Tensor, batch: dict[str, torch.Tensor]) -> torch.Tensor:
    """Accuracy at the synthetic task's answer position."""

    if torch is None:
        raise ModuleNotFoundError("answer_accuracy requires torch")
    batch_indices = torch.arange(logits.shape[0], device=logits.device)
    answer_logits = logits[batch_indices, batch["answer_index"].to(logits.device)]
    predictions = answer_logits.argmax(dim=-1)
    return (predictions == batch["answer_token"].to(logits.device)).float().mean()


def value_answer_cross_entropy(logits: torch.Tensor, batch: dict[str, torch.Tensor]) -> torch.Tensor:
    """Cross-entropy at the answer position restricted to valid value tokens."""

    if torch is None:
        raise ModuleNotFoundError("value_answer_cross_entropy requires torch")
    value_start = int(batch["value_start"][0].item())
    num_values = int(batch["num_values"][0].item())
    batch_indices = torch.arange(logits.shape[0], device=logits.device)
    answer_logits = logits[
        batch_indices,
        batch["answer_index"].to(logits.device),
        value_start : value_start + num_values,
    ]
    value_targets = batch["answer_token"].to(logits.device) - value_start
    return torch.nn.functional.cross_entropy(answer_logits, value_targets)


def value_answer_accuracy(logits: torch.Tensor, batch: dict[str, torch.Tensor]) -> torch.Tensor:
    """Accuracy at the answer position after restricting predictions to value tokens."""

    if torch is None:
        raise ModuleNotFoundError("value_answer_accuracy requires torch")
    value_start = int(batch["value_start"][0].item())
    num_values = int(batch["num_values"][0].item())
    batch_indices = torch.arange(logits.shape[0], device=logits.device)
    answer_logits = logits[
        batch_indices,
        batch["answer_index"].to(logits.device),
        value_start : value_start + num_values,
    ]
    predictions = answer_logits.argmax(dim=-1) + value_start
    return (predictions == batch["answer_token"].to(logits.device)).float().mean()


def value_random_chance(batch: dict[str, torch.Tensor]) -> float:
    """Random-answer baseline for value-only prediction."""

    return 1.0 / float(int(batch["num_values"][0].item()))

"""Training-only losses and diagnostics for UABLA routing."""

from __future__ import annotations

import torch
import torch.nn.functional as F

from .routing import CandidateSelection


def teacher_attention_to_region_targets(
    teacher_attention: torch.Tensor,
    *,
    region_size_tokens: int,
    num_regions: int | None = None,
    eps: float = 1e-8,
) -> torch.Tensor:
    """Convert dense teacher attention into region-level routing targets.

    teacher_attention may have shape [batch, seq, seq] or [batch, heads, seq, seq].
    This function is training-only; it is not used at inference.
    """

    if teacher_attention.ndim == 4:
        teacher_attention = teacher_attention.mean(dim=1)
    if teacher_attention.ndim != 3:
        raise ValueError("teacher_attention must be [batch, seq, seq] or [batch, heads, seq, seq]")
    if region_size_tokens <= 0:
        raise ValueError("region_size_tokens must be positive")
    teacher_attention = teacher_attention.float()

    batch, query_len, key_len = teacher_attention.shape
    if num_regions is None:
        num_regions = (key_len + region_size_tokens - 1) // region_size_tokens
    padded_key_len = num_regions * region_size_tokens
    pad_len = padded_key_len - key_len
    if pad_len > 0:
        teacher_attention = F.pad(teacher_attention, (0, pad_len))

    targets = teacher_attention.view(batch, query_len, num_regions, region_size_tokens).sum(dim=-1)
    normalizer = targets.sum(dim=-1, keepdim=True).clamp_min(eps)
    return targets / normalizer


def routing_distillation_loss(
    route_scores: torch.Tensor,
    routeable_mask: torch.Tensor,
    teacher_attention: torch.Tensor,
    *,
    region_size_tokens: int,
    eps: float = 1e-8,
) -> torch.Tensor:
    """Distill dense teacher attention mass into UABLA route probabilities.

    route_scores and routeable_mask are shaped [batch, seq, regions, 4].
    The loss trains block or superblock routing without changing inference.
    """

    if route_scores.shape != routeable_mask.shape:
        raise ValueError("route_scores and routeable_mask must have the same shape")
    route_scores = route_scores.float()
    teacher_attention = teacher_attention.float()
    batch, seq_len, num_regions, centroids_per_region = route_scores.shape
    targets = teacher_attention_to_region_targets(
        teacher_attention,
        region_size_tokens=region_size_tokens,
        num_regions=num_regions,
        eps=eps,
    )
    if targets.shape[:2] != (batch, seq_len):
        raise ValueError("teacher_attention batch/sequence dimensions must match route_scores")

    routeable_regions = routeable_mask.any(dim=-1)
    targets = targets * routeable_regions.to(targets.dtype)
    target_mass = targets.sum(dim=-1, keepdim=True)
    valid = (target_mass.squeeze(-1) > eps) & routeable_regions.any(dim=-1)
    if not bool(valid.any()):
        return route_scores.new_zeros(())
    targets = targets / target_mass.clamp_min(eps)

    flat_scores = route_scores.reshape(batch, seq_len, num_regions * centroids_per_region)
    flat_mask = routeable_mask.reshape(batch, seq_len, num_regions * centroids_per_region)
    flat_scores = flat_scores[valid]
    flat_mask = flat_mask[valid]
    targets = targets[valid]
    safe_scores = flat_scores.masked_fill(~flat_mask, torch.finfo(flat_scores.dtype).min)
    centroid_probs = torch.softmax(safe_scores, dim=-1) * flat_mask.to(flat_scores.dtype)
    centroid_probs = centroid_probs / centroid_probs.sum(dim=-1, keepdim=True).clamp_min(eps)
    region_probs = centroid_probs.reshape(
        -1,
        num_regions,
        centroids_per_region,
    ).sum(dim=-1)

    per_token = -(targets * torch.log(region_probs.clamp_min(eps))).sum(dim=-1)
    return per_token.mean()


def guarded_budget_loss(
    token_budgets: torch.Tensor,
    *,
    logits: torch.Tensor | None = None,
    prediction_entropy: torch.Tensor | None = None,
    max_budget: int | None = None,
    confidence_threshold: float = 0.55,
    guard_temperature: float = 0.1,
    detach_guard: bool = True,
    eps: float = 1e-8,
) -> torch.Tensor:
    """Penalize budget mostly when the model is already prediction-confident."""

    if max_budget is None:
        max_budget = int(token_budgets.max().item())
    if max_budget <= 0:
        raise ValueError("max_budget must be positive")
    if prediction_entropy is None:
        if logits is None:
            raise ValueError("either logits or prediction_entropy must be provided")
        logits = logits.float()
        probs = torch.softmax(logits, dim=-1)
        prediction_entropy = -(probs * torch.log(probs.clamp_min(eps))).sum(dim=-1)
        max_entropy = torch.log(torch.tensor(logits.shape[-1], device=logits.device, dtype=logits.dtype))
        confidence = 1.0 - prediction_entropy / max_entropy.clamp_min(eps)
    else:
        confidence = 1.0 - prediction_entropy

    guard = torch.sigmoid((confidence - confidence_threshold) / guard_temperature)
    if detach_guard:
        guard = guard.detach()
    budget_fraction = token_budgets.to(guard.dtype) / float(max_budget)
    return (guard * budget_fraction).mean()


def routing_diagnostics(
    candidates: CandidateSelection,
    route_scores: torch.Tensor,
    routeable_mask: torch.Tensor,
    *,
    attention: torch.Tensor | None = None,
    eps: float = 1e-8,
) -> dict[str, torch.Tensor]:
    """Return compact training diagnostics for router health."""

    batch, seq_len, num_regions, centroids_per_region = route_scores.shape
    route_scores = route_scores.float()
    flat_scores = route_scores.reshape(batch, seq_len, num_regions * centroids_per_region)
    flat_mask = routeable_mask.reshape(batch, seq_len, num_regions * centroids_per_region)
    safe_scores = flat_scores.masked_fill(~flat_mask, torch.finfo(flat_scores.dtype).min)
    probs = torch.softmax(safe_scores, dim=-1) * flat_mask.to(flat_scores.dtype)
    probs = probs / probs.sum(dim=-1, keepdim=True).clamp_min(eps)
    entropy = -(probs * torch.log(probs.clamp_min(eps))).sum(dim=-1)
    valid = flat_mask.any(dim=-1)
    mean_entropy = entropy[valid].mean() if bool(valid.any()) else entropy.sum() * 0.0

    diagnostics = {
        "route_entropy": mean_entropy,
        "avg_open_blocks": candidates.opened_block_mask.sum(dim=-1).float().mean(),
        "avg_centroid_budget": candidates.centroid_budgets.float().mean(),
        "avg_token_budget": candidates.token_budgets.float().mean(),
    }
    if candidates.opened_superblock_mask is not None:
        diagnostics["avg_open_superblocks"] = (
            candidates.opened_superblock_mask.sum(dim=-1).float().mean()
        )
    if candidates.superblock_budgets is not None:
        diagnostics["avg_superblock_budget"] = candidates.superblock_budgets.float().mean()
    if attention is not None:
        attention = attention.float()
        diagnostics["attention_entropy"] = -(
            attention * torch.log(attention.clamp_min(eps))
        ).sum(dim=-1).mean()
    return diagnostics
